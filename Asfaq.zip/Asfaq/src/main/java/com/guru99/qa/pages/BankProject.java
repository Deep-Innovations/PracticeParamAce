package com.guru99.qa.pages;

public class BankProject {

}
